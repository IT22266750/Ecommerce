-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2024 at 02:28 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystore`
--
CREATE DATABASE IF NOT EXISTS `mystore` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `mystore`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `Brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brandtitle` varchar(100) NOT NULL,
  PRIMARY KEY (`Brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`Brand_id`, `brandtitle`) VALUES
(1, 'SONY'),
(2, 'CANON'),
(3, 'ADIDAS'),
(4, 'NIKE'),
(5, 'ZIPPO'),
(6, 'VO'),
(7, '');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `categorytitle` varchar(100) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `categorytitle`) VALUES
(1, 'Shoes'),
(2, 'Bag'),
(3, 'chocolates'),
(4, 'Dress'),
(5, 'books'),
(6, 'Beauty Products'),
(7, 'Phone');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `productid` int(11) NOT NULL AUTO_INCREMENT,
  `producttitle` varchar(100) NOT NULL,
  `productdescription` varchar(255) NOT NULL,
  `productkeyword` varchar(255) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `brandid` int(11) NOT NULL,
  `productimage1` varchar(255) NOT NULL,
  `productimage2` varchar(255) NOT NULL,
  `productimage3` varchar(255) NOT NULL,
  `productimage4` varchar(255) NOT NULL,
  `productprice` varchar(100) NOT NULL,
  `date` timestamp NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
